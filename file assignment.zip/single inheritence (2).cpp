#include<iostream>
#include<conio.h>
using namespace std;
class student
{
	public:
	string name;
	int age;
	void getdata()
	{
    cout<<"enter your name="<<endl;
    cin>>name;
    cout<<"enter your age="<<endl;
    cin>>age;
}
};
class Ali:public student
{
	public:
	int no1,no2,no3,tot;
	float per;
		void getmarks()
	{
	cout<<"enter your first no="<<endl;
	cin>>no1;
	cout<<"enter your second no="<<endl;
	cin>>no2;
	cout<<"enter your third no="<<endl;
	cin>>no3;
}
     void display()
     {
     	getmarks();
	cout<<"name" + name<<age + age<<no1<<no2<<no3<<tot<<per;
}
};
int main()
{
	Ali a1;
	a1.getdata();
	a1.display();
}
