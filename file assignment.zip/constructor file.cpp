#include<iostream>
#include<conio.h>
using namespace std;
class student
{
	protected:
	int student_number;
	string student_name;
	double student_average;
	
	student(void)
	{
		student_number=327;
		student_name="mujeeb";
		student_average=44;
	}
	

	void display()
	{
		cout<<"My number is this="<<student_number<<endl;
		cout<<"your name is this ="<<student_name<<endl;
		cout<<"your average number is this="<<student_average<<endl;
	}
};
class graduate_students:public student
{
	public:
	char level;
	int year;

	graduate_students()
	{
		//student();
		level='A';
		year=2024;
	}
	void display1()
	{
		display();
		cout<<"My level is this="<<level<<endl;
		cout<<"my year is this="<<year<<endl;
	}
};
class master:protected graduate_students
{ 
public:
int newid;

   master()
{
	newid=0327;
	}	
	void display2()
	{
		display1();
		cout<<"My id is this="<<newid<<endl;
	}
};
int main()
{
master m2;
m2.display2();   

}

