#include<iostream>
#include<conio.h>
using namespace std;
class baba
{
	public:
		string name;
		int age;
		void setdata()
		{
			name="mujeeb";
			age=19;
		}
};
class mama
{
public:	  
	string name_mama;
	bool married;
	
	void setdata1()
	{
      name_mama="Aliza";
      married="yes";
      
		}
};
class son:public baba,public mama
{
        public:
       int no;
	    void getdata2()
{
	 setdata();
	 setdata1();
	  no=327;
}
void printdata()
{
	cout<<"your baba name="<<name<<endl;
	cout<<"your baba's age="<<age<<endl;
	cout<<"your name_mama="<<name_mama<<endl;
	cout<<"your mama is married="<<married<<endl;
	cout<<"enter your number="<<no<<endl;
}
};
int main()

{
	son s1;
s1.getdata2();
s1.printdata();

}

