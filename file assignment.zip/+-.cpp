#include<iostream>
using namespace std;
int main()
{
	int a;
	char b;
	int c,
	result;
	
	cout<<"enter your number="<<endl;
	cin>>a;
	cout<<"enter your sign="<<endl;
	cin>>b;		
	cout<<"enter your number="<<endl;
	cin>>c;	
	if(b=='*')
	{
		result=a*c;
	cout<<"result="<<result<<endl;
	}
	if(b=='/')
    {
    	result=a/c;
	cout<<"result="<<result<<endl;
    }
	if(b=='+')
	{
		result=a+c;
	cout<<"result=" <<result<<endl;
	}
	if(b=='-')
    {
    	result=a-c;
    cout<<"result="<<result<<endl;
	}
}

